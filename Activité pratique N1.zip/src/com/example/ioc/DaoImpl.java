package com.example.ioc;

public class DaoImpl implements IDao {
    @Override
    public String getData() {
        return "Données récupérées depuis DaoImpl";
    }
}