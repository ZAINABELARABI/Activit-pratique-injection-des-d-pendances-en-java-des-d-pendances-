package com.example.ioc;

public class MainDynamic {
    public static void main(String[] args) throws Exception {
        Class<?> daoClass = Class.forName("com.example.ioc.DaoImpl");
        IDao dao = (IDao) daoClass.getDeclaredConstructor().newInstance();

        Class<?> metierClass = Class.forName("com.example.ioc.MetierImpl");
        IMetier metier = (IMetier) metierClass.getDeclaredConstructor(IDao.class).newInstance(dao);

        System.out.println("Résultat calcul : " + metier.calcul());
    }
}