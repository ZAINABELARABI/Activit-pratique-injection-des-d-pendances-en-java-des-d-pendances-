package com.example.ioc;

public interface IMetier {
    double calcul();
}