package com.example.ioc.miniFramework.container;

import com.example.ioc.miniFramework.annotations.MyAutowired;
import com.example.ioc.miniFramework.annotations.MyComponent;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.reflections.Reflections;

public class MyApplicationContext {
    private Map<Class<?>, Object> beans = new HashMap<>();

    public MyApplicationContext(String basePackage) throws Exception {
        Reflections reflections = new Reflections(basePackage);
        Set<Class<?>> types = reflections.getTypesAnnotatedWith(MyComponent.class);
        for (Class<?> clazz : types) {
            Object instance = clazz.getDeclaredConstructor().newInstance();
            beans.put(clazz, instance);
        }
        for (Object bean : beans.values()) {
            injectDependencies(bean);
        }
    }

    private void injectDependencies(Object bean) throws IllegalAccessException {
        Field[] fields = bean.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (field.isAnnotationPresent(MyAutowired.class)) {
                field.setAccessible(true);
                Object dependency = beans.get(field.getType());
                field.set(bean, dependency);
            }
        }
    }

    public <T> T getBean(Class<T> clazz) {
        return clazz.cast(beans.get(clazz));
    }
}