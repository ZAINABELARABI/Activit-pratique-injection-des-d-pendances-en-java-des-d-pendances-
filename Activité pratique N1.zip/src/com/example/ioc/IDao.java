package com.example.ioc;

public interface IDao {
    String getData();
}