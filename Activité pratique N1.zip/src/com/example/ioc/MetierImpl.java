package com.example.ioc;

public class MetierImpl implements IMetier {
    private IDao dao;

    public MetierImpl(IDao dao) {
        this.dao = dao;
    }

    @Override
    public double calcul() {
        String data = dao.getData();
        System.out.println("Traitement des données : " + data);
        return 42;
    }
}