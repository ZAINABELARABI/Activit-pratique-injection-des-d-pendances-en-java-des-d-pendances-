package com.example.ioc.spring;

import org.springframework.stereotype.Component;

@Component
public class DaoSpring implements com.example.ioc.IDao {
    @Override
    public String getData() {
        return "Données via Spring Annotation";
    }
}