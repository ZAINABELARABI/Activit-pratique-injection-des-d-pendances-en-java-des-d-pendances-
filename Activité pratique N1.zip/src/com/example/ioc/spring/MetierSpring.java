package com.example.ioc.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MetierSpring implements com.example.ioc.IMetier {
    private final com.example.ioc.IDao dao;

    @Autowired
    public MetierSpring(com.example.ioc.IDao dao) {
        this.dao = dao;
    }

    @Override
    public double calcul() {
        System.out.println("Traitement avec Spring Annotation");
        return 42;
    }
}